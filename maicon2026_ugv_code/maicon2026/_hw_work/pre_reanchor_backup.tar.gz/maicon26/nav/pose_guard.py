"""자세 감시(PoseGuard): 충격 감지, LiDAR 장착 틀어짐, SLAM 도약, 경기장(UAV) 좌표 연결 점검.

왜 필요한가
  - Nav2Stack 은 시작 때 한 번 정한 Anchor(경기장 = Anchor ∘ map)로 SLAM 자세를 경기장(UAV) 좌표로 옮긴다. 그 뒤로는 연결이 맞는지 다시 보지 않는다.
  - 충돌로 LiDAR 가 차체에 대해 돌아가면 SLAM 은 '틀어진 LiDAR'를 정확히 따라간다. 그래서 SLAM 자세의 헤딩에 상수 편차 δ 가 생기고,
    차체 기준의 바퀴·IMU 헤딩과는 어긋난다 — δ = (SLAM 헤딩 − 차체 헤딩) 의 충격 전후 차이.
  - 이 파일은 ROS·Gazebo 없이 시험할 수 있는 순수 계산이다. 연결은 Nav2Stack.update / Agent._sense 가 한다.

네 가지 일
  1. ImpactDetector : IMU 가속도(+자이로)로 충돌을 IMU 주기에서 잡는다. 방향(차체 기준 접촉 방위)·세기를 낸다.
  2. 틀어짐 추정   : 충격 전 기준 오프셋(SLAM 헤딩 − 차체 헤딩)과 충격 후 정지 상태 오프셋의 차이 = LiDAR 장착 yaw 틀어짐.
                      확정되면 자세 헤딩에서 빼고(pose.th -= δ) 스캔 각도에 더한다(scan.angles += δ). 크면 Nav2 대신 내장 A* 로 간다
                      (Nav2 의 TF 는 Agent 가 못 고친다).
  3. SLAM 도약 감시 : 한 틱에 예측(이전 자세 + 오도메트리 변화)에서 크게 벗어난 SLAM 자세는 바로 믿지 않고 몇 표본 동안 확인한다.
                      TF 가 끊겨도 제한된 시간 동안 IMU/바퀴 추측항법으로 자세를 이어 간다. 그 시간을 넘으면 'lost'.
  4. 경기장 연결 점검: LiDAR 끝점을 경기장 외벽·고정 구조물 13개(+UAV 상자 윤곽)에 맞춰 본다. 시작 때의 맞음 정도를 기준선으로 삼고(경기장 도면
                      치수 오차는 기준선에 흡수된다) 그 뒤 크게 나빠졌을 때만 '복구용' 소폭 보정을 제안한다. 평상시 절대 보정은 하지 않는다.

모든 각도는 내부에서 rad. 설정(PoseGuardCfg)은 deg·m·s.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Deque, Dict, List, Optional, Sequence, Tuple

import numpy as np

from ..types import Pose2D, Scan
from ..util import wrap

Rect = Tuple[float, float, float, float]          # (cx, cy, sx, sy) 경기장 좌표 — UAV 상자 윤곽


# ====================================================================== 1. 충돌 감지
@dataclass
class ImpactEvent:
    t: float
    peak_dg: float                       # 기준선에서 벗어난 최대 가속도 [g]
    bearing: Optional[float]             # 접촉 방위(차체 기준 rad, 0 = 앞, 왼쪽 +). 모르면 None
    gyro_dps: float = 0.0                # 충격 순간 yaw 각속도 크기 [deg/s] (없으면 0)
    src: str = "accel"                   # accel | gyro | yaw_step
    major_dg: float = 1.2
    major_gyro_dps: float = 400.0

    @property
    def severity(self) -> str:
        return "major" if (self.peak_dg >= self.major_dg or self.gyro_dps >= self.major_gyro_dps) else "minor"

    @property
    def sector(self) -> str:
        if self.bearing is None:
            return "unknown"
        a = abs(wrap(self.bearing))
        if a <= math.radians(50):
            return "front"
        if a >= math.radians(130):
            return "rear"
        return "left" if self.bearing > 0 else "right"


class ImpactDetector:
    """IMU 표본마다 부르는 충돌 감지기. 느리게 변하는 기준선(중력·기울기·가속)에서 갑자기 벗어난 가속도를 충돌로 본다.

    - 기준선은 지수이동평균(시정수 baseline_tau_s). 충격 표본은 기준선에 섞지 않는다.
    - 문턱 = max(trigger_dg, noise_k × 최근 평균 편차) — 거친 바닥의 모터 진동이 충돌로 오인되지 않게 한다.
    - 편차가 sustain_s 넘게 이어지면 충돌이 아니라 기울기 변화(경사로)로 보고 기준선을 현재 값으로 옮긴다.
    - ax, ay(차체 기준 수평 가속도 [g])가 있으면 방향을 낸다: 몸이 받은 가속도의 반대쪽이 접촉 방위.
    - 한 번의 충돌은 refractory_s 안에 한 번만 낸다(그 안의 더 큰 값은 같은 사건의 peak 에 반영).
    스레드: IMU 콜백 스레드에서 add(), Agent 스레드에서 pop() — 내부 deque 가 한 방향이라 별도 잠금은 쓰지 않는다."""

    def __init__(self, trigger_dg: float = 0.45, major_dg: float = 1.2, gyro_dps: float = 180.0, major_gyro_dps: float = 400.0,
                 refractory_s: float = 0.35, baseline_tau_s: float = 1.5, noise_k: float = 5.0, warmup_s: float = 0.5,
                 sustain_s: float = 0.6) -> None:
        self.trigger_dg, self.major_dg, self.gyro_dps, self.major_gyro_dps = trigger_dg, major_dg, gyro_dps, major_gyro_dps
        self.refractory_s, self.tau, self.noise_k, self.warmup_s, self.sustain_s = refractory_s, baseline_tau_s, noise_k, warmup_s, sustain_s
        self._t0: Optional[float] = None
        self._tp: Optional[float] = None
        self._bg = self._bx = self._by = 0.0
        self._noise = 0.03
        self._n_noise = 0
        self._until = -1e18
        self._cur: Optional[ImpactEvent] = None
        self._cur_h = 0.0
        self._trig_since: Optional[float] = None
        self.events: Deque[ImpactEvent] = deque(maxlen=32)
        self.count = 0

    def add(self, t: float, g: float, ax: Optional[float] = None, ay: Optional[float] = None,
            gz_dps: Optional[float] = None) -> Optional[ImpactEvent]:
        if not (math.isfinite(t) and math.isfinite(g)):
            return None
        if self._tp is not None and t <= self._tp:
            return None                                              # 시각이 거꾸로 가는 표본은 버린다
        has_xy = ax is not None and ay is not None and math.isfinite(ax) and math.isfinite(ay)
        if self._t0 is None:
            self._t0, self._tp, self._bg = t, t, g
            if has_xy:
                self._bx, self._by = float(ax), float(ay)
            return None
        dt = t - self._tp
        self._tp = t
        alpha = 1.0 - math.exp(-min(dt, 0.5) / max(self.tau, 1e-3))
        dev_g = g - self._bg
        hx, hy = (ax - self._bx, ay - self._by) if has_xy else (0.0, 0.0)
        dh = math.hypot(hx, hy)
        mag = max(abs(dev_g), dh)
        gyro = abs(gz_dps) if gz_dps is not None and math.isfinite(gz_dps) else 0.0
        thr = max(self.trigger_dg, self.noise_k * self._noise)
        warm = (t - self._t0) < self.warmup_s
        trig = (not warm) and (mag >= thr or gyro >= self.gyro_dps)
        if not trig:
            self._trig_since = None
            self._bg += alpha * dev_g
            if has_xy:
                self._bx += alpha * hx
                self._by += alpha * hy
            self._n_noise += 1
            a_noise = max(alpha, 1.0 / self._n_noise) if warm else alpha          # 시작 구간은 단순 평균으로 잡음 수준을 빨리 잡는다
            self._noise += a_noise * (min(mag, 0.5) - self._noise)
            return None
        rising = self._trig_since is None
        if rising:
            self._trig_since = t
        else:
            if self._cur is not None:                                              # 같은 덩어리의 후속 표본: 더 큰 값은 같은 사건에 반영
                if mag > self._cur.peak_dg:
                    self._cur.peak_dg = mag
                if gyro > self._cur.gyro_dps:
                    self._cur.gyro_dps = gyro
                if has_xy and dh > self._cur_h and dh >= 0.5 * thr:
                    self._cur_h, self._cur.bearing = dh, math.atan2(-hy, -hx)
            if t - self._trig_since >= self.sustain_s:
                self._bg, self._trig_since = g, None                                # 이어지는 편차 = 기울기 변화: 기준선을 옮긴다
                if has_xy:
                    self._bx, self._by = float(ax), float(ay)
            return None
        if self._cur is not None and t < self._until:                              # refractory 안의 두 번째 덩어리 = 같은 충돌
            if mag > self._cur.peak_dg:
                self._cur.peak_dg = mag
            if gyro > self._cur.gyro_dps:
                self._cur.gyro_dps = gyro
            return None
        ev = ImpactEvent(t, mag, math.atan2(-hy, -hx) if (has_xy and dh >= 0.5 * mag and dh >= 0.5 * thr) else None, gyro,
                         "gyro" if (gyro >= self.gyro_dps and mag < thr) else "accel", self.major_dg, self.major_gyro_dps)
        self._cur, self._cur_h, self._until = ev, dh, t + self.refractory_s
        self.events.append(ev)
        self.count += 1
        return ev

    def pop(self) -> List[ImpactEvent]:
        out: List[ImpactEvent] = []
        while self.events:
            out.append(self.events.popleft())
        return out


# ====================================================================== 2. 경기장 맞춤 (벽·구조물·UAV 상자)
def wall_heading_residual(points: np.ndarray, max_gap: float = 0.12) -> Optional[Tuple[float, float, int]]:
    """경기장 좌표 점들(스캔 각도 순서, N×2)에서 '축 정렬 선분'의 방향 편차 ψ [rad, (-π/4, π/4]]와 집중도 R(0..1), 쌍 수.
    경기장 벽·구조물·박스는 모두 축에 정렬(20 cm 격자)이라, 올바른 자세라면 ψ ≈ 0 이다. 도면 치수 오차와 무관한 헤딩 점검이다.
    4θ 원형 평균(90° 대칭)을 쓴다. 이어진 점(간격 < max_gap)만 선분으로 센다."""
    if points is None or len(points) < 8:
        return None
    d = points[1:] - points[:-1]
    L = np.hypot(d[:, 0], d[:, 1])
    ok = (L > 0.008) & (L < max_gap)
    if ok.sum() < 6:
        return None
    th = np.arctan2(d[ok, 1], d[ok, 0])
    w = L[ok]
    z = np.sum(w * np.exp(4j * th))
    tot = float(np.sum(w))
    return float(np.angle(z) / 4.0), float(abs(z) / max(tot, 1e-9)), int(ok.sum())


class ArenaFit:
    """LiDAR 끝점 ↔ 외벽 + 고정 구조물(+UAV 상자 윤곽) 거리장. ArenaEdgeMap 의 거리장을 재사용한다."""

    def __init__(self, width: float, height: float, rectangles=None, resolution: float = 0.025) -> None:
        from .arena_localization import ArenaEdgeMap
        if rectangles is None:
            try:
                from .arena_localization import fixed_infrastructure_rectangles
                rectangles = fixed_infrastructure_rectangles()
            except Exception:                                        # noqa: BLE001 — 구조물 목록이 없으면 외벽만
                rectangles = ()
        self.map = ArenaEdgeMap(width, height, rectangles, resolution)
        self.width, self.height = width, height

    @staticmethod
    def rect_distance(points: np.ndarray, rects: Sequence[Rect]) -> np.ndarray:
        """각 점에서 가장 가까운 사각형 '윤곽'까지 거리(안쪽도 윤곽까지)."""
        shape = points.shape[:-1]
        p = points.reshape(-1, 2)
        best = np.full(len(p), np.inf)
        for cx, cy, sx, sy in rects:
            hx, hy = sx / 2.0, sy / 2.0
            dx, dy = np.abs(p[:, 0] - cx) - hx, np.abs(p[:, 1] - cy) - hy
            outside = np.hypot(np.maximum(dx, 0.0), np.maximum(dy, 0.0))
            inside = -np.maximum(dx, dy)
            d = np.where((dx > 0) | (dy > 0), outside, inside)
            best = np.minimum(best, d)
        return best.reshape(shape)

    def distance(self, points: np.ndarray, rects: Sequence[Rect] = ()) -> np.ndarray:
        d = self.map.distances(points)
        return np.minimum(d, self.rect_distance(points, rects)) if len(rects) else d

    @staticmethod
    def scan_points(scan: Scan, max_pts: int = 140, rmin: float = 0.15, rmax: float = 7.5) -> np.ndarray:
        """스캔 → 차체 기준 끝점(N×2, 각도 순서 유지). max_pts 개로 균등 솎는다."""
        valid = scan.valid() & (scan.ranges > rmin) & (scan.ranges < rmax)
        idx = np.flatnonzero(valid)
        if len(idx) < 12:
            return np.zeros((0, 2))
        if len(idx) > max_pts:
            idx = idx[np.linspace(0, len(idx) - 1, max_pts).astype(int)]
        a, r = scan.angles[idx], scan.ranges[idx]
        return np.column_stack([r * np.cos(a), r * np.sin(a)])

    @staticmethod
    def to_arena(points_base: np.ndarray, pose: Sequence[float]) -> np.ndarray:
        c, s = math.cos(pose[2]), math.sin(pose[2])
        return np.column_stack([pose[0] + c * points_base[:, 0] - s * points_base[:, 1],
                                pose[1] + s * points_base[:, 0] + c * points_base[:, 1]])

    def score(self, points_base: np.ndarray, pose: Sequence[float], rects: Sequence[Rect] = (),
              sigma: float = 0.05, inlier: float = 0.06) -> Tuple[float, float]:
        """(가우시안 점수 0..1, 설명된 비율 0..1). 설명된 비율 = 윤곽에서 inlier 안에 든 끝점 비율."""
        if len(points_base) == 0:
            return 0.0, 0.0
        d = self.distance(self.to_arena(points_base, pose), rects)
        return float(np.mean(np.exp(-0.5 * (d / sigma) ** 2))), float(np.mean(d < inlier))

    def _batch(self, points_base: np.ndarray, base_pose: Sequence[float], offs: np.ndarray, rects: Sequence[Rect],
               sigma: float) -> np.ndarray:
        th = base_pose[2] + offs[:, 2:3]
        c, s = np.cos(th), np.sin(th)
        ex = base_pose[0] + offs[:, 0:1] + c * points_base[None, :, 0] - s * points_base[None, :, 1]
        ey = base_pose[1] + offs[:, 1:2] + s * points_base[None, :, 0] + c * points_base[None, :, 1]
        d = self.distance(np.stack([ex, ey], axis=-1), rects)
        return np.mean(np.exp(-0.5 * (d / sigma) ** 2), axis=1)

    def search(self, points_base: np.ndarray, pose: Sequence[float], rects: Sequence[Rect] = (),
               xy: float = 0.15, th: float = math.radians(6.0), sigma: float = 0.05) -> Dict[str, Any]:
        """자세 주변(±xy m, ±th rad)에서 점수가 가장 높은 오프셋을 굵은→가는 격자로 찾는다.
        반환: off=(dx,dy,dth), s0(0 오프셋 점수), sb(최고 점수), obs=(x,y,th 가 관측 가능한가) — 관측 불가 축(벽 하나만 보일 때 벽을 따르는 방향)은
        점수가 평평해 최고점 위치가 임의이므로 호출자가 0 으로 취급해야 한다."""
        if len(points_base) < 20:
            return {"ok": False}
        coarse_x = np.linspace(-xy, xy, 7)
        coarse_t = np.linspace(-th, th, 7)
        offs = np.array([(a, b, c) for a in coarse_x for b in coarse_x for c in coarse_t])
        sc = self._batch(points_base, pose, offs, rects, sigma)
        best = offs[int(np.argmax(sc))]
        fx, ft = (coarse_x[1] - coarse_x[0]) * 0.5, (coarse_t[1] - coarse_t[0]) * 0.5
        fine = np.array([(best[0] + a, best[1] + b, best[2] + c) for a in np.linspace(-fx, fx, 5)
                         for b in np.linspace(-fx, fx, 5) for c in np.linspace(-ft, ft, 5)])
        sc2 = self._batch(points_base, pose, fine, rects, sigma)
        k = int(np.argmax(sc2))
        best, sb = fine[k], float(sc2[k])
        s0 = float(self._batch(points_base, pose, np.zeros((1, 3)), rects, sigma)[0])
        probe_xy, probe_th = 0.05, math.radians(2.5)
        probes = np.array([best + np.array(v) for v in
                           ((probe_xy, 0, 0), (-probe_xy, 0, 0), (0, probe_xy, 0), (0, -probe_xy, 0), (0, 0, probe_th), (0, 0, -probe_th))])
        sp = self._batch(points_base, pose, probes, rects, sigma)
        drop = np.array([sb - max(sp[0], sp[1]), sb - max(sp[2], sp[3]), sb - max(sp[4], sp[5])])
        obs = tuple(bool(v >= 0.035) for v in drop)
        # 격자 가장자리에서 끝난 최적은 '더 멀리 있을 수 있다' — 신뢰하지 않는다
        edge = bool(abs(best[0]) >= xy - 1e-6 or abs(best[1]) >= xy - 1e-6 or abs(best[2]) >= th - 1e-6)
        return {"ok": True, "off": (float(best[0]), float(best[1]), float(best[2])), "s0": s0, "sb": sb, "obs": obs, "edge": edge}


# ====================================================================== 3. 자세 감시
def _circ_median(vals: Sequence[float]) -> float:
    """각도 값들의 원형 중앙값(첫 값 기준으로 펼친 뒤 중앙값)."""
    v = np.asarray(vals, dtype=float)
    ref = v[0]
    return float(wrap(ref + float(np.median([wrap(x - ref) for x in v]))))


def _circ_std(vals: Sequence[float]) -> float:
    v = np.asarray(vals, dtype=float)
    m = _circ_median(vals)
    return float(np.sqrt(np.mean([wrap(x - m) ** 2 for x in v])))


class PoseGuard:
    """SLAM 자세 → 경기장(UAV) 좌표 자세를 감시·보정한다. 설정 키는 config.PoseGuardCfg 참고."""

    def __init__(self, cfg: Any, geo: Any, *, rectangles=None, fit: Optional[ArenaFit] = None,
                 log: Optional[Callable[[float, str], None]] = None) -> None:
        self.c, self.geo = cfg, geo
        self._log = log or (lambda t, m: None)
        self.fit: Optional[ArenaFit] = fit
        self._fit_rects = rectangles
        self.pose: Optional[Pose2D] = None
        self._odom_prev: Optional[Pose2D] = None
        self._t_prev: Optional[float] = None
        self.state = "ok"                                   # ok | degraded | lost
        self.reasons: List[str] = []
        self.last_fix_t: Optional[float] = None
        self.rot = 0.0                                      # 평활한 yaw 변화율 [rad/s] (오도메트리)
        self.lin = 0.0                                      # 평활한 선속도 [m/s]
        self.fixes = 0
        self.dead_reckoned = 0
        self.jumps_held = 0
        self.jumps_accepted = 0
        # ---- LiDAR 장착 yaw 틀어짐
        self.shift = 0.0                                    # 확정된 누적 틀어짐 δ [rad]
        self.shift_events: List[Dict[str, Any]] = []
        self._d_hist: Deque[Tuple[float, float]] = deque(maxlen=400)
        self._d_anchor: Optional[float] = None              # 마지막으로 확인된 (SLAM 헤딩 − 차체 헤딩) 기준 오프셋
        self._v: Optional[Dict[str, Any]] = None            # 진행 중인 충격 후 검증
        self.verify_results: List[Dict[str, Any]] = []
        # ---- SLAM 도약
        self._jump: Optional[Dict[str, Any]] = None
        # ---- 경기장 연결
        self.uav_rects: List[Rect] = []
        self._link_t = -1e9
        self._link_base: Optional[Dict[str, Any]] = None
        self.link: Dict[str, Any] = {"state": "unchecked"}
        self._link_bad: List[Tuple[float, float, float]] = []
        self._trim_req: Optional[Tuple[float, float, float]] = None
        self._trim_total = [0.0, 0.0, 0.0]
        self.trims_applied = 0
        self.link_checks = 0
        self._moving_t = -1e9
        self._link_disabled = False
        self._shift_unverified = False                      # 충격 후 틀어짐을 판정하지 못했거나 보정 한도를 넘었다 → 내장 A* 로 간다

    def set_log(self, fn: Callable[[float, str], None]) -> None:
        self._log = fn

    # ------------------------------------------------------------------ 외부에서 쓰는 값
    @property
    def verifying(self) -> bool:
        return self._v is not None

    @property
    def shift_applied(self) -> float:
        return self.shift if getattr(self.c, "shift_compensate", True) else 0.0

    @property
    def needs_builtin_nav(self) -> bool:
        """LiDAR 틀어짐이 Nav2 로 계속 가기엔 크다(Nav2 의 TF 는 Agent 가 못 고친다) → 내장 A* 로 간다."""
        return self._shift_unverified or abs(math.degrees(self.shift)) >= float(self.c.fallback_deg)

    @property
    def speed_scale(self) -> float:
        return float(self.c.degraded_speed_scale) if self.state == "degraded" else 1.0

    def set_uav_rects(self, rects: Sequence[Rect]) -> None:
        self.uav_rects = [tuple(map(float, r)) for r in rects if len(r) == 4 and all(math.isfinite(float(v)) for v in r)]

    def correct_scan(self, scan: Optional[Scan]) -> Optional[Scan]:
        """차체 기준 스캔 각도 보정: LiDAR 가 +δ 돌아갔으면 같은 빔은 실제로 차체 기준 +δ 방향이다. 스캔을 새로 만든다(원본은 그대로)."""
        d = self.shift_applied
        if scan is None or abs(d) < 1e-9:
            return scan
        import dataclasses
        return dataclasses.replace(scan, angle_min=scan.angle_min + d)

    def take_trim(self) -> Optional[Tuple[float, float, float]]:
        t, self._trim_req = self._trim_req, None
        return t

    def mark_impact(self, now: float, severity: str = "minor", bearing: Optional[float] = None, src: str = "accel") -> None:
        """충격이 있었다(now = 충격 시각) → 그 직전의 기준 오프셋을 굳히고 충격 후 검증을 시작한다.
        src='yaw_step' 은 충격 센서가 못 잡은 오프셋 계단이라, 계단 이전에 학습해 둔 기준(_d_anchor)을 그대로 쓴다."""
        if src == "yaw_step" and self._d_anchor is not None:
            ref = (self._d_anchor, math.radians(self.c.pre_std_deg), 0)
        else:
            ref = self._reference(now - 0.05)
        self._v = {"t": now, "ref": ref, "post": [], "severity": severity, "bearing": bearing,
                   "t_end": now + float(self.c.verify_timeout_s), "result": None}
        self._log(now, f"PoseGuard: 충격({severity}) — 검증 시작, 기준 오프셋 "
                       f"{'없음' if ref is None else f'{math.degrees(ref[0]):+.1f}° (±{math.degrees(ref[1]):.1f}°, n={ref[2]})'}")

    def verify_done(self) -> bool:
        return self._v is None

    # ------------------------------------------------------------------ 내부: 기준 오프셋
    def _reference(self, t_before: float) -> Optional[Tuple[float, float, int]]:
        c = self.c
        vals = [d for (t, d) in self._d_hist if t_before - c.pre_window_s <= t <= t_before]
        if len(vals) >= 5:
            std = _circ_std(vals)
            if std <= math.radians(c.pre_std_deg):
                return _circ_median(vals), std, len(vals)
        if self._d_anchor is not None:                               # 최근 표본이 모자라면 마지막으로 확인된 기준
            return self._d_anchor, math.radians(c.pre_std_deg), 0
        return None

    # ------------------------------------------------------------------ 메인
    def process(self, now: float, raw: Optional[Pose2D], odom: Pose2D, scan: Optional[Scan] = None) -> Pose2D:
        """raw: SLAM(TF) 에서 온 경기장 좌표 자세(LiDAR 틀어짐이 섞인 것) 또는 None(TF 없음). odom: 차체 오도메트리(IMU 융합일 수 있다).
        scan: 새 스캔일 때만(이미 correct_scan 을 거친 것). 반환: 보정·검증을 거친 자세."""
        c = self.c
        dt = None if self._t_prev is None else max(now - self._t_prev, 1e-3)
        body = None
        if self._odom_prev is not None and dt is not None:
            dx, dy = odom.x - self._odom_prev.x, odom.y - self._odom_prev.y
            ct, st = math.cos(self._odom_prev.th), math.sin(self._odom_prev.th)
            body = (ct * dx + st * dy, -st * dx + ct * dy, wrap(odom.th - self._odom_prev.th))
            if math.hypot(body[0], body[1]) > 0.5 or abs(body[2]) > 1.0:
                body = None                                          # 오도메트리 리셋·도약은 이동량으로 쓰지 않는다
        if body is not None and dt is not None:
            k = min(1.0, dt / 0.3)
            self.rot += k * (abs(body[2]) / dt - self.rot)
            self.lin += k * (math.hypot(body[0], body[1]) / dt - self.lin)
        self._odom_prev, self._t_prev = odom.copy(), now
        pred = None
        if body is not None and self.pose is not None:
            p = self.pose
            cp, sp = math.cos(p.th), math.sin(p.th)
            pred = Pose2D(p.x + cp * body[0] - sp * body[1], p.y + sp * body[0] + cp * body[1], wrap(p.th + body[2]))
        if self.rot >= math.radians(c.quiet_rot_dps):
            self._moving_t = now
        if raw is None:
            return self._no_fix(now, pred)
        fixed = Pose2D(raw.x, raw.y, wrap(raw.th - self.shift_applied))
        # ---- SLAM 도약 점검
        if pred is not None and self.pose is not None:
            far = math.hypot(fixed.x - pred.x, fixed.y - pred.y) > c.jump_m or abs(wrap(fixed.th - pred.th)) > math.radians(c.jump_deg)
            if far:
                accepted = self._handle_jump(now, fixed, pred, scan)
                if not accepted:
                    return self._hold(now, pred)
            else:
                self._jump = None
        elif self.pose is None:
            self._jump = None
        self.pose = fixed
        self.last_fix_t = now
        self.fixes += 1
        # ---- 충격 전 기준/충격 후 검증에 쓰는 오프셋 표본 (SLAM 헤딩 − 차체 헤딩)
        d = wrap(raw.th - odom.th)
        if self.rot < math.radians(c.quiet_rot_dps):
            self._d_hist.append((now, d))
        self._verify_step(now, d, scan)
        if scan is not None and c.link_check and not self._link_disabled:
            self._link_step(now, scan)
        reasons = self._degraded_reasons(now)
        self._set_state(now, "degraded" if reasons else "ok", reasons)
        return self.pose

    # ------------------------------------------------------------------ TF 끊김 · 도약
    def _no_fix(self, now: float, pred: Optional[Pose2D]) -> Pose2D:
        c = self.c
        age = None if self.last_fix_t is None else now - self.last_fix_t
        if self.pose is None:
            return Pose2D()
        if pred is not None and age is not None and age <= c.dead_reckon_s:
            self.pose = pred
            self.dead_reckoned += 1
            self._set_state(now, "degraded", ["tf_miss_dead_reckoning"])
        elif age is not None and age > c.dead_reckon_s:
            self._set_state(now, "lost", ["tf_lost"])
        return self.pose

    def _hold(self, now: float, pred: Pose2D) -> Pose2D:
        c = self.c
        self.pose = pred
        self.jumps_held += 1
        t0 = self._jump["t0"] if self._jump else now
        if now - t0 > c.dead_reckon_s:
            self._set_state(now, "lost", ["slam_jump_unresolved"])
        else:
            self._set_state(now, "degraded", ["slam_jump_hold"])
        return pred

    def _handle_jump(self, now: float, fixed: Pose2D, pred: Pose2D, scan: Optional[Scan]) -> bool:
        """예측에서 크게 벗어난 SLAM 자세: 연속 표본이 한 곳에 모이고(재국소화) 경기장 맞음이 나빠지지 않을 때만 받아들인다."""
        c = self.c
        j = self._jump
        if j is None or math.hypot(fixed.x - j["p"].x, fixed.y - j["p"].y) > 0.10 or abs(wrap(fixed.th - j["p"].th)) > math.radians(6.0):
            self._jump = {"t0": now if j is None else j["t0"], "n": 1, "p": fixed.copy()}
            return False
        j["n"] += 1
        if j["n"] < c.jump_confirm_n:
            return False
        forced = now - j["t0"] > 2.0 * c.dead_reckon_s
        if self.fit is None and c.link_check and not self._link_disabled:
            self._ensure_fit()
        if self.fit is not None and scan is not None and not forced:
            pts = self.fit.scan_points(scan)
            if len(pts) >= 30:
                sf, rf = self.fit.score(pts, (fixed.x, fixed.y, fixed.th), self.uav_rects)
                sp, rp = self.fit.score(pts, (pred.x, pred.y, pred.th), self.uav_rects)
                if rp > rf + 0.10:
                    if not j.get("rejected"):
                        self._log(now, f"PoseGuard: SLAM 도약 거부(경기장 맞음 예측 {rp:.2f} > SLAM {rf:.2f}) — 추측항법 유지")
                    j["rejected"] = True                              # 예측 자리가 훨씬 잘 맞는다 — 시간 상한(forced)까지 거부한다
                    return False
                j["rejected"] = False
        if forced:
            self._log(now, "PoseGuard: SLAM 도약이 오래 이어져 SLAM 자세를 최선으로 받아들인다(추측항법은 그동안 누적 오차)")
        self.jumps_accepted += 1
        self._jump = None
        self._d_hist.clear()                                           # 재국소화로 헤딩 오프셋이 바뀌는 것은 LiDAR 틀어짐이 아니다
        self._d_anchor = None
        self._log(now, f"PoseGuard: SLAM 도약 수용 ({pred.x:.2f},{pred.y:.2f})→({fixed.x:.2f},{fixed.y:.2f})")
        return True

    # ------------------------------------------------------------------ 충격 후 틀어짐 검증
    def _verify_step(self, now: float, d: float, scan: Optional[Scan]) -> None:
        v, c = self._v, self.c
        if v is None:
            self._learn_anchor(d)
            return
        if now >= v["t_end"]:
            self._finish_verify(now, "timeout")
            return
        if scan is None or now - v["t"] < c.settle_s:
            return
        if self.rot >= math.radians(c.quiet_rot_dps) or self.lin > c.quiet_lin:
            return                                                     # 정지 상태의 표본만 쓴다
        v["post"].append(d)
        if len(v["post"]) < c.shift_confirm_scans:
            return
        std = _circ_std(v["post"])
        if std > math.radians(c.post_std_deg):
            if len(v["post"]) >= 3 * c.shift_confirm_scans:
                self._finish_verify(now, "noisy")
            else:
                v["post"].pop(0)
            return
        self._finish_verify(now, "measured")

    def _finish_verify(self, now: float, how: str) -> None:
        v, c = self._v, self.c
        self._v = None
        res: Dict[str, Any] = {"t": v["t"], "severity": v["severity"], "how": how, "delta_deg": None, "action": "none"}
        if how == "measured" and v["ref"] is not None:
            self._shift_unverified = False
            post = _circ_median(v["post"])
            delta = wrap(post - v["ref"][0])
            res["delta_deg"] = round(math.degrees(delta), 2)
            res["post_deg"] = round(math.degrees(post), 2)
            if abs(delta) >= math.radians(c.shift_detect_deg):
                if abs(delta) <= math.radians(c.shift_max_deg):
                    self.shift = wrap(self.shift + delta)
                    res["action"] = "shift_confirmed"
                    self.shift_events.append({"t": v["t"], "delta_deg": res["delta_deg"], "total_deg": round(math.degrees(self.shift), 2)})
                    self._log(now, f"PoseGuard: LiDAR 장착 틀어짐 확정 δ={math.degrees(delta):+.1f}° (누적 {math.degrees(self.shift):+.1f}°)"
                                   f" → 자세 헤딩·스캔 각도 보정{' · 내장 A* 로 전환' if self.needs_builtin_nav else ''}")
                else:
                    res["action"] = "too_large"
                    self._shift_unverified = True
                    self._log(now, f"PoseGuard: 충격 후 헤딩 오프셋 {math.degrees(delta):+.1f}° — 보정 한도({c.shift_max_deg:.0f}°) 초과, 보정하지 않고 내장 A* 로 간다")
            self._d_anchor = post
            self._d_hist.clear()
            self._d_hist.extend((now, x) for x in v["post"][-5:])
        elif how == "measured":
            self._d_anchor = _circ_median(v["post"])
            res["action"] = "no_reference"
            self._log(now, "PoseGuard: 충격 후 오프셋을 쟀지만 충격 전 기준이 없어 틀어짐을 판정하지 못했다 — 이 값을 새 기준으로")
        else:
            res["action"] = "unverified"
            self._shift_unverified = v["severity"] == "major"      # 큰 충격인데 확인하지 못했다 → Nav2 헤딩을 믿지 않는다. 작은 충격은 의심만 하고 계속
            self._d_anchor = None
            self._log(now, f"PoseGuard: 충격 후 검증 {how} — 틀어짐 여부를 확인하지 못했다(자세를 의심하며 계속)")
        self.verify_results.append(res)
        del self.verify_results[:-8]

    def _learn_anchor(self, d: float) -> None:
        """충격이 없을 때도 기준 오프셋을 천천히 따라간다(IMU 헤딩 드리프트·바퀴 미끄럼을 흡수). 급변은 따라가지 않는다."""
        if self.rot >= math.radians(self.c.quiet_rot_dps):
            return
        if self._d_anchor is None:
            if len(self._d_hist) >= 10:
                recent = [x for _, x in list(self._d_hist)[-10:]]
                if _circ_std(recent) <= math.radians(self.c.pre_std_deg):
                    self._d_anchor = _circ_median(recent)
            return
        err = wrap(d - self._d_anchor)
        if abs(err) <= math.radians(self.c.shift_detect_deg):
            self._d_anchor = wrap(self._d_anchor + 0.02 * err)

    def step_detected(self, now: float) -> Optional[ImpactEvent]:
        """충격 센서가 못 잡은 '오프셋 계단'(정지 상태에서 SLAM−차체 헤딩이 갑자기 한도 이상 변함)을 가상 충격으로 본다. 호출자가 mark_impact 한다."""
        c = self.c
        if self._v is not None or self._d_anchor is None or len(self._d_hist) < 4:
            return None
        recent = [x for (t, x) in list(self._d_hist)[-4:]]
        if _circ_std(recent) > math.radians(c.pre_std_deg):
            return None
        err = wrap(_circ_median(recent) - self._d_anchor)
        if abs(err) >= math.radians(c.step_trigger_deg) and now - self._moving_t >= 0.3:
            return ImpactEvent(now, 0.0, None, 0.0, "yaw_step")
        return None

    # ------------------------------------------------------------------ 경기장(UAV) 좌표 연결 점검
    def _ensure_fit(self) -> None:
        if self.fit is None:
            try:
                self.fit = ArenaFit(self.geo.W, self.geo.H, self._fit_rects)
            except Exception as e:                                       # noqa: BLE001 — 점검 보조가 제어 루프를 죽이면 안 된다
                self.link = {"state": "unavailable", "why": f"{type(e).__name__}: {e}"}
                self._link_disabled = True

    def _link_step(self, now: float, scan: Scan) -> None:
        c = self.c
        if now - self._link_t < c.link_period_s or self.pose is None:
            return
        if self.rot > math.radians(c.link_rot_dps) or self.lin > c.link_lin or self._v is not None:
            return                                                       # 움직임 왜곡이 큰 동안은 점검하지 않는다
        self._link_t = now
        self._ensure_fit()
        if self.fit is None or self._link_disabled:
            return
        pts = self.fit.scan_points(scan)
        if len(pts) < 40:
            return
        p = self.pose
        pose = (p.x, p.y, p.th)
        s0, r0 = self.fit.score(pts, pose, self.uav_rects)
        arena_pts = self.fit.to_arena(pts, pose)
        hd = wall_heading_residual(arena_pts)
        st_static = self.fit.map.distances(arena_pts)
        unexplained = st_static > 0.08
        uav_support = None
        if self.uav_rects and unexplained.sum() >= 10:
            uav_support = float(np.mean(self.fit.rect_distance(arena_pts[unexplained], self.uav_rects) < 0.06))
        self.link_checks += 1
        rep: Dict[str, Any] = {"t": round(now, 2), "ratio": round(r0, 3), "score": round(s0, 3),
                               "wall_psi_deg": None if hd is None else round(math.degrees(hd[0]), 2),
                               "wall_R": None if hd is None else round(hd[1], 2),
                               "uav_support": None if uav_support is None else round(uav_support, 3),
                               "uav_boxes": len(self.uav_rects), "n_pts": int(len(pts))}
        need_search = self._link_base is None or r0 < self._link_base["ratio"] - c.link_drop
        found = self.fit.search(pts, pose, self.uav_rects, xy=c.link_search_xy, th=math.radians(c.link_search_deg)) if need_search else {"ok": False}
        if found.get("ok"):
            rep["best_off"] = [round(found["off"][0], 3), round(found["off"][1], 3), round(math.degrees(found["off"][2]), 2)]
            rep["best_gain"] = round(found["sb"] - found["s0"], 3)
            rep["obs"] = list(found["obs"])
        if self._link_base is None:
            if r0 >= c.link_baseline_min and found.get("ok") and not found["edge"]:
                self._link_base = {"ratio": r0, "off": found["off"], "psi": None if hd is None else hd[0], "t": now}
                rep["state"] = "baseline"
                self._log(now, f"PoseGuard: 경기장 연결 기준선 — 벽·구조물 맞음 {r0:.2f}, 도면과의 잔차 "
                               f"({found['off'][0]:+.3f},{found['off'][1]:+.3f}) m {math.degrees(found['off'][2]):+.1f}° "
                               f"(이 값은 도면 치수·시작 자세 오차로 보고 기준선에 흡수한다)")
            else:
                rep["state"] = "poor_start" if r0 < c.link_baseline_min else "searching"
        else:
            base = self._link_base
            rep["base_ratio"] = round(base["ratio"], 3)
            if r0 >= max(c.link_lost_ratio, base["ratio"] - c.link_drop):
                rep["state"] = "ok"
                self._link_bad.clear()
            else:
                rep["state"] = "bad" if r0 < c.link_lost_ratio else "weak"
                self._maybe_trim(now, r0, found, rep)
        self.link = rep

    def _maybe_trim(self, now: float, r0: float, found: Dict[str, Any], rep: Dict[str, Any]) -> None:
        """연결이 기준선보다 크게 나빠졌을 때만(SLAM 도약·재국소화 실패·앵커 어긋남) 소폭 '복구 보정'을 제안한다.
        관측 가능한 축만, 연속 3회 같은 결과, 점수 회복 조건, 누적 한도를 모두 만족해야 한다."""
        c = self.c
        base = self._link_base
        if not getattr(c, "link_trim", False) or not found.get("ok") or found["edge"]:
            return
        if found["sb"] - found["s0"] < c.link_trim_gain:
            self._link_bad.clear()
            return
        dx, dy, dth = found["off"]
        ox, oy, oth = base["off"]
        rel = [dx - ox if found["obs"][0] else 0.0, dy - oy if found["obs"][1] else 0.0, wrap(dth - oth) if found["obs"][2] else 0.0]
        if not any(found["obs"]):
            self._link_bad.clear()
            return
        self._link_bad.append((rel[0], rel[1], rel[2]))
        del self._link_bad[:-3]
        if len(self._link_bad) < 3:
            return
        a = np.array(self._link_bad)
        if np.ptp(a[:, 0]) > 0.04 or np.ptp(a[:, 1]) > 0.04 or np.ptp(a[:, 2]) > math.radians(1.5):
            return
        m = a.mean(axis=0)
        tot = [self._trim_total[0] + m[0], self._trim_total[1] + m[1], self._trim_total[2] + m[2]]
        if math.hypot(tot[0], tot[1]) > c.link_trim_max_m or abs(tot[2]) > math.radians(c.link_trim_max_deg):
            rep["trim"] = "limit"
            self._log(now, "PoseGuard: 연결 복구 보정이 누적 한도를 넘는다 — 더 보정하지 않는다(연결 불량 상태로 계속)")
            self._link_bad.clear()
            return
        self._trim_req = (float(m[0]), float(m[1]), float(m[2]))
        self._trim_total = tot
        self._link_bad.clear()
        rep["trim"] = [round(float(m[0]), 3), round(float(m[1]), 3), round(math.degrees(float(m[2])), 2)]
        self._log(now, f"PoseGuard: 연결 복구 보정 제안 ({m[0]:+.3f},{m[1]:+.3f}) m {math.degrees(m[2]):+.1f}° (맞음 {r0:.2f} → 회복 예상 {found['sb']:.2f})")

    def note_trim_applied(self, trim: Tuple[float, float, float]) -> None:
        """스택이 앵커에 보정을 적용했다 — 보정 후의 자세와 기준 오프셋을 맞춘다."""
        if self.pose is not None:
            self.pose = Pose2D(self.pose.x + trim[0], self.pose.y + trim[1], wrap(self.pose.th + trim[2]))
        self.trims_applied += 1
        self._d_hist.clear()
        self._d_anchor = None
        self._link_t = -1e9

    # ------------------------------------------------------------------ 상태
    def _degraded_reasons(self, now: float) -> List[str]:
        out: List[str] = []
        if self._shift_unverified:
            out.append("lidar_shift_unverified")
        if abs(self.shift) >= math.radians(self.c.shift_detect_deg):
            out.append("lidar_shift_compensated")
        if self.link.get("state") in ("weak", "bad", "poor_start") and self.c.link_degrades:
            out.append("link_" + str(self.link["state"]))
        if self._v is not None:
            out.append("impact_verifying")
        return out

    def _set_state(self, now: float, state: str, reasons: List[str]) -> None:
        if state == "ok" and self.state == "lost":
            self._log(now, "PoseGuard: lost → ok (새 SLAM 자세 수신)")
        self.state, self.reasons = state, reasons

    def report(self) -> Dict[str, Any]:
        p = self.pose
        return {"state": self.state, "reasons": list(self.reasons),
                "pose": None if p is None else [round(p.x, 3), round(p.y, 3), round(p.th, 3)],
                "shift_deg": round(math.degrees(self.shift), 2), "shift_events": list(self.shift_events[-4:]),
                "needs_builtin_nav": self.needs_builtin_nav, "verifying": self.verifying,
                "last_verify": self.verify_results[-1] if self.verify_results else None,
                "fixes": self.fixes, "dead_reckoned": self.dead_reckoned, "jumps_held": self.jumps_held,
                "jumps_accepted": self.jumps_accepted, "link": dict(self.link), "link_checks": self.link_checks,
                "trims_applied": self.trims_applied,
                "trim_total": [round(self._trim_total[0], 3), round(self._trim_total[1], 3), round(math.degrees(self._trim_total[2]), 2)]}
