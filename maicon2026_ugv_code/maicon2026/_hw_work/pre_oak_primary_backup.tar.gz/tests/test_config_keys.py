"""10장 설정 키: 새 키가 기본값·로드·병합·알 수 없는 키 거부·실기 설정 불변·launch 인자에서 문서대로 동작하는지. 시뮬을 쓰지 않는다."""
import json
from pathlib import Path

import pytest

from maicon26.config import Config
from maicon26.launch_profile import load_run_config, scan_self_mask_args
from maicon26.oak_launch import oak_enabled

ROOT = Path(__file__).resolve().parents[1]

# (섹션, 키, 문서의 기본값) — 10장 표 그대로
DEFAULTS = [
    ("camera", "model", "pinhole"), ("camera", "D", None), ("camera", "usable_hfov_deg", None),
    ("aim", "gimbal_settle_s", 0.0), ("aim", "settle_move_deg", 1.0),
    ("laser", "practice_empty_backoff_s", 10.0),
    ("oak", "launch_cmd", ("ros2", "launch", "depthai_ros_driver", "camera.launch.py")), ("oak", "launch_args", ()),
    ("oak", "profile", "rgb_lowpower"),
    ("oak", "rgb_topic", "/oak/rgb/image_raw"), ("oak", "rgb_info_topic", "/oak/rgb/camera_info"),
    ("oak", "check_topics_after_s", 8.0),
    ("oak_det", "enable", False), ("oak_det", "conf", 0.35), ("oak_det", "max_hz", 3.0), ("oak_det", "pause_in_strike", True),
    ("oak_det", "weight", 0.5), ("oak_det", "submit_alone", False), ("oak_det", "save_max", 8),
    ("oak_det", "save_every_s", 2.0), ("oak_det", "cleanup_every_s", 30.0), ("oak_det", "save_dir", None),
    ("rig", "oak_rgb_rpy", (0.0, 0.0, 0.0)),
    ("hal", "fire_left_ms_max", 15000.0), ("hal", "frozen_frames", 20), ("hal", "dark_frames", 30),
    ("perception", "min_box_px", 4.0),
    ("link", "max_command_chars", 500),
    # LiDAR 면 지도·OAK 식별 단계·깊이 항법 잠금(코드 기본은 모두 꺼짐 — 실기 설정 파일에서만 켠다)
    ("explore", "uav_face_registry", False), ("explore", "redetect_resolved", True), ("avoid", "friend_track", False), ("avoid", "friend_lost_s", 4.0),
    ("avoid", "friend_gate_m", 0.5), ("explore", "lidar_faces", False), ("explore", "lidar_face_min_len_m", 0.40), ("explore", "lidar_ugv_exclude_m", 0.30),
    ("oak_det", "on_demand", False), ("oak_det", "identify_fallback", False), ("oak_det", "identify_submit", False),
    ("oak_det", "identify_dist_m", 0.8), ("depth", "nav_allowed", False),
]

# 문서의 기본이 '다른 키와 같다/창 없음' 으로 적힌 키
SPECIAL = [("oak_det", "vote_window", None), ("rig", "oak_rgb_xyz", None)]


@pytest.mark.parametrize("section,key,default", DEFAULTS)
def test_every_new_key_exists_with_the_documented_default(section, key, default):
    assert getattr(getattr(Config(), section), key) == default


def test_keys_documented_as_following_another_default_do_follow_it():
    cfg = Config()
    assert cfg.oak_det.vote_window is None                                  # 창 없음 = 팬틸트 쪽과 같은 규칙(perception.min_votes 만)
    assert cfg.rig.oak_rgb_xyz == cfg.rig.depth_xyz                         # rig.depth_xyz 와 같다


NON_DEFAULT = {
    "camera": {"model": "fisheye", "D": [0.1, -0.02, 0.0, 0.0], "usable_hfov_deg": 120.0,
               "K": [300.0, 0.0, 320.0, 0.0, 300.0, 240.0, 0.0, 0.0, 1.0]},
    "aim": {"gimbal_settle_s": 0.4, "settle_move_deg": 2.5},
    "laser": {"practice_empty_backoff_s": 4.0},
    "oak": {"launch_cmd": ["ros2", "run", "x", "y"], "launch_args": ["camera_model:=OAK-D-LITE"], "profile": "rgbd",
            "rgb_topic": "/cam/rgb", "rgb_info_topic": "/cam/info", "check_topics_after_s": 3.0},
    "oak_det": {"enable": True, "conf": 0.5, "max_hz": 2.0, "pause_in_strike": False, "vote_window": 8, "weight": 0.7,
                "submit_alone": True, "save_max": 4, "save_every_s": 1.0, "cleanup_every_s": 10.0, "save_dir": "/tmp/x"},
    "rig": {"oak_rgb_xyz": [0.07, 0.0, 0.03], "oak_rgb_rpy": [0.0, 0.1, 0.0]},
    "hal": {"fire_left_ms_max": 12000.0, "frozen_frames": 10, "dark_frames": 15},
    "perception": {"min_box_px": 6.0},
    "link": {"max_command_chars": 300},
}


def test_every_new_key_can_be_loaded_from_a_config_file_and_lists_become_tuples(tmp_path):
    p = tmp_path / "c.json"
    p.write_text(json.dumps(NON_DEFAULT), encoding="utf-8")
    cfg = Config.load(str(p))
    for section, keys in NON_DEFAULT.items():
        for key, want in keys.items():
            got = getattr(getattr(cfg, section), key)
            got = tuple(got) if isinstance(got, list) else got               # 기본이 None 인 Optional 키(camera.D·K)는 로더가 리스트를 그대로 둔다 — 쓰는 쪽이 tuple 로 바꾼다
            assert got == (tuple(want) if isinstance(want, list) else want), (section, key)
    assert isinstance(cfg.oak.launch_args, tuple) and isinstance(cfg.rig.oak_rgb_xyz, tuple)     # 기본이 tuple 인 키는 tuple 로 바뀐다
    from maicon26.perception.camera import CameraModel
    cm = CameraModel(cfg.camera)                                            # 파일에서 읽은 K·D(리스트)로도 어안 모델이 선다
    assert cm.model == "fisheye" and cm.D == (0.1, -0.02, 0.0, 0.0) and cm.usable_hfov_deg == 120.0


def test_new_keys_merge_over_the_real_config_and_leave_the_rest_alone(tmp_path):
    ov = tmp_path / "ov.json"
    ov.write_text(json.dumps({"oak_det": {"enable": True, "max_hz": 2.0}, "aim": {"gimbal_settle_s": 0.3}}), encoding="utf-8")
    base, _ = load_run_config(str(ROOT / "config" / "waveshare_real.json"), None, "nav2", root=ROOT)
    merged = Config.load(str(ov))
    assert merged.oak_det.enable and merged.oak_det.max_hz == 2.0 and merged.aim.gimbal_settle_s == 0.3
    assert merged.oak_det.conf == base.oak_det.conf and merged.laser.ammo == base.laser.ammo      # 건드리지 않은 값


def test_config_round_trips_through_to_dict_with_the_new_keys(tmp_path):
    cfg = Config.load(None)
    cfg.camera.model, cfg.oak_det.max_hz, cfg.link.max_command_chars = "fisheye", 2.5, 321
    p = tmp_path / "rt.json"
    p.write_text(json.dumps(cfg.to_dict(), default=list), encoding="utf-8")
    back = Config.load(str(p))
    assert (back.camera.model, back.oak_det.max_hz, back.link.max_command_chars) == ("fisheye", 2.5, 321)
    assert back.oak_det.save_max == cfg.oak_det.save_max and back.hal.frozen_frames == cfg.hal.frozen_frames


@pytest.mark.parametrize("section,key", [(s, k) for s, k, _ in DEFAULTS] + [(s, k) for s, k, _ in SPECIAL])
def test_unknown_keys_next_to_the_new_ones_are_rejected_not_ignored(tmp_path, section, key):
    p = tmp_path / "bad.json"
    p.write_text(json.dumps({section: {key + "_typo": 1}}), encoding="utf-8")
    with pytest.raises(KeyError, match="알 수 없는 설정 키"):
        Config.load(str(p))


def test_unknown_section_is_rejected_too(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text(json.dumps({"oak_detect": {"enable": True}}), encoding="utf-8")
    with pytest.raises(KeyError):
        Config.load(str(p))


def test_the_real_robot_config_keeps_every_default_this_work_must_not_change():
    cfg, _ = load_run_config(str(ROOT / "config" / "waveshare_real.json"), None, "nav2", root=ROOT)
    assert cfg.camera.model == "pinhole" and cfg.camera.D is None and cfg.camera.usable_hfov_deg is None
    assert cfg.aim.gimbal_settle_s == 0.0
    # OAK 검출은 실기에서 '식별 단계에서만'(on_demand) 켠다 — 항상 켜 두지 않고, OAK 단독 제출(submit_alone)도 열지 않는다
    assert cfg.oak_det.enable is True and cfg.oak_det.on_demand is True and cfg.oak_det.submit_alone is False
    default = Config()
    assert cfg.lidar.self_mask_sectors == default.lidar.self_mask_sectors      # 자기 가림 구간은 현장 측정 전까지 바꾸지 않는다


def test_oak_driver_is_off_unless_the_environment_variable_says_one(monkeypatch):
    assert oak_enabled({}) is False and oak_enabled({"MAICON_OAK": ""}) is False and oak_enabled({"MAICON_OAK": "0"}) is False
    assert oak_enabled({"MAICON_OAK": "1"}) is True and oak_enabled({"MAICON_OAK": " 1 "}) is True


def test_scan_mask_launch_arguments_are_absent_by_default_and_follow_the_config():
    cfg = Config()
    assert cfg.lidar.self_mask_range == 0.35 and cfg.lidar.min_range == 0.0
    if not cfg.lidar.self_mask_sectors:
        assert scan_self_mask_args(cfg.lidar) == []                         # 빈 값 / 0 — 기존 launch 명령과 같다
    cfg.lidar.self_mask_sectors = ((3.14, 0.4),)
    cfg.lidar.min_range = 0.12
    assert scan_self_mask_args(cfg.lidar) == ["scan_self_mask:=3.14:0.4", "scan_self_mask_range:=0.35", "scan_min_range:=0.12"]
    cfg.lidar.self_mask_sectors = ()
    assert scan_self_mask_args(cfg.lidar) == ["scan_self_mask_range:=0.35", "scan_min_range:=0.12"]   # min_range 만이어도 마스크는 켜진다


def test_every_registered_tunable_is_a_real_config_key():
    from maicon26.field.tunables import TUNABLES
    cfg = Config()
    missing = []
    for t in TUNABLES:
        obj = cfg
        try:
            for part in t.path.split("."):
                obj = getattr(obj, part)
        except AttributeError:
            missing.append(t.path)
    assert missing == []
