from types import SimpleNamespace as NS
from pathlib import Path
import pytest
from maicon26.config import Config
from maicon26.preflight import wait_ready, validate_model_labels, validate_real_config, clear_standby_restore


class Clock:
    t = 0.0
    def __call__(self): return self.t
    def sleep(self, dt): self.t += dt


def test_sensor_timeout_never_becomes_ready():
    c = Clock()
    with pytest.raises(TimeoutError, match="odom"):
        wait_ready(NS(readiness=lambda: (False, ["odom"])), NS(), .4, clock=c, sleep=c.sleep)


def test_nav2_requires_tf_even_with_all_sensors():
    c = Clock()
    stack = NS(client=NS(available=lambda: True, lookup_map_to_base=lambda: None))
    with pytest.raises(TimeoutError, match="TF"):
        wait_ready(NS(readiness=lambda: (True, [])), stack, .3, clock=c, sleep=c.sleep)


def test_standby_ready_does_not_require_motion_permission():
    wait_ready(NS(readiness=lambda: (True, [])), NS(), .1)


def test_rejects_generic_yolo_and_accepts_mapped_labels():
    cfg = Config()
    with pytest.raises(ValueError, match="필수 클래스"):
        validate_model_labels(NS(model=NS(names={0: "person"}), names_map={}), cfg)
    labels = list(cfg.perception.object_classes + cfg.perception.target_classes) + [
        "UGV", "COMMAND_POST", "MAINT_DEPOT", "SUPPLY_BASE"]
    mapping = {"label" + str(i): v for i, v in enumerate(labels)}
    validate_model_labels(NS(model=NS(names=list(mapping)), names_map=mapping), cfg)


def test_real_profile_separates_cmd_and_disables_uncalibrated_depth():
    cfg = Config.load(str(Path(__file__).resolve().parents[1] / "config/waveshare_real.json"))
    validate_real_config(cfg)
    assert cfg.nav2.base_frame == "base_footprint"
    assert not cfg.depth.enable and not cfg.nav2.publish_depth_obstacles
    cfg.nav2.cmd_topic = cfg.hal.cmd_topic
    with pytest.raises(ValueError, match="분리"):
        validate_real_config(cfg)


def test_old_start_cleared_only_during_new_standby(tmp_path):
    p = tmp_path / "start.json"
    p.write_text('{}')
    robot = NS(status=lambda: NS(match_mode="mission", match_cmd="resume"))
    clear_standby_restore(robot, str(p))
    assert p.exists()
    robot.status = lambda: NS(match_mode="mission", match_cmd="standby")
    clear_standby_restore(robot, str(p))
    assert not p.exists()


def test_real_depth_requires_measurement_and_actual_optical_frame():
    cfg = Config.load(str(Path(__file__).resolve().parents[1] / "config/waveshare_real.json"))
    cfg.depth.enable = True
    with pytest.raises(ValueError, match="calibration_verified"):
        validate_real_config(cfg)
    cfg.depth.calibration_verified = True
    with pytest.raises(ValueError, match="optical_frame"):
        validate_real_config(cfg)
    cfg.depth.optical_frame = "actual_depth_optical_frame"
    validate_real_config(cfg)
    cfg.depth.tf_tolerance_m = float("nan")
    with pytest.raises(ValueError, match="허용값"):
        validate_real_config(cfg)


def test_relative_velocity_topic_cannot_alias_final_actuator_topic():
    cfg = Config.load(str(Path(__file__).resolve().parents[1] / "config/waveshare_real.json"))
    cfg.nav2.cmd_topic = "cmd_vel"
    with pytest.raises(ValueError, match="절대 이름"):
        validate_real_config(cfg)


def test_depth_preflight_error_identifies_the_bad_input():
    c = Clock()
    robot = NS(readiness=lambda: (False, ["depth"]), stats={"depth_error": "CameraInfo frame mismatch"})
    with pytest.raises(TimeoutError, match="CameraInfo frame mismatch"):
        wait_ready(robot, NS(), .1, clock=c, sleep=c.sleep)


@pytest.mark.parametrize("timeout", [float("nan"), float("inf"), float("-inf"), 0])
def test_invalid_deadline_cannot_wait_forever(timeout):
    with pytest.raises(ValueError, match="finite and positive"):
        wait_ready(NS(), NS(), timeout)
